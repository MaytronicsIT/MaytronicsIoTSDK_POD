//
//  MaytronicsIoTSDK.h
//  MaytronicsIoTSDK
//
//  Created by Harel Avikasis on 14/05/2020.
//  Copyright © 2020 Maytronics. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for MaytronicsIoTSDK.
FOUNDATION_EXPORT double MaytronicsIoTSDKVersionNumber;

//! Project version string for MaytronicsIoTSDK.
FOUNDATION_EXPORT const unsigned char MaytronicsIoTSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <MaytronicsIoTSDK/PublicHeader.h>


